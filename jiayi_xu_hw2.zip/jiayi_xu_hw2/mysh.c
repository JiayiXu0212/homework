
/*
  Name: Jiayi Xu
  Class: CS360
  Date: 01/29/2021
  Project: Assignment2
  Description: Create a shell and call it mysh.
*/


#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

/*
* Parse input 
*/
char **parseInput(char *input, int *count){
	char *token=NULL;
	
	// use malloc to dynamically allocate a single block of memory with specified size 256
	char **cmmd=malloc(256 * sizeof(char *));
	int index=0;
	char *temp=NULL;
	
	// Use strtok_r to parse input
	token=strtok_r(input," ",&temp);
	// To check every token
	while(token!=NULL){
		cmmd[index++]=token;
		token = strtok_r(NULL, " ",&temp);
	}
	cmmd[index]=NULL;
	*count=index;
	return cmmd;
}

/*
* Read input 
* When user types something and presses the Enter key, the string read may contain the newline character ( '\n' ) at its end
* this function is for strip that out
*/
char *readInput(FILE *fp,size_t s){
	char *line;
	int l;
	size_t len=0;
	// dynamically reallocate memory
	line = realloc(NULL,sizeof(char)*s);
	if(!line){
		return line;
	}
	
	// strip out '\n'
	while('\n' != (l=fgetc(fp))){
		line[len++]=l;
		if (len==s){
			line = realloc(line,sizeof(char)*(s+=16));
			if(!line){
				return line;
			}
		}
	}
	line[len++]='\0';
	return realloc(line,sizeof(char)*len);
}

/*
*  Main function 
*/
int main(){
	char **args = NULL; 
	pid_t rc;   // initialize a variable for fork()
	while(1){
		char *cmmd=NULL;
		int count=0;
		printf("$mysh > ");  // The prompt start with "$mysh > " every time
		
		
		cmmd=readInput(stdin,10);
		
		// if user enter nothing, will print out "Failed to read command
		if (strcmp(cmmd,"")==0){
			printf("Failed to read command\n");
		}
		// if user enter "exit" will exit the program
		if (strcmp(cmmd,"exit")==0){
			exit(0);
		}
		// parse input
		args=(char **)parseInput(cmmd,&count);
		
		// Continue to read input
		if (count == 0){
			continue;
		}
		// if the first word of input is "cd", will run "cd" command and check its condition
		if(strcmp(args[0],"cd")==0){
			if(chdir(args[1])<0){
				fprintf(stderr,"%s\n",strerror(errno));
			}
			continue;
		}
		
		// create a precess
		rc=fork();
		// fork failed
		if(rc<0){
			fprintf(stderr,"Failed to create process\n");
			exit(1);
		}
		if (rc==0){
			
			// Command failed to execute
			if(execvp(args[0],args)<0){
				printf("Failed to execute command\n");
			}
			exit(0);
		}
		else{
			wait(NULL);
		}
	}
	return 0;
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
